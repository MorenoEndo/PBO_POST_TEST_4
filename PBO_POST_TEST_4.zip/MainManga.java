public class MainManga {
    public static void main(String[] args) {
        MangaManager manager = new MangaManager();

        // Overloading tambahManga()
        manager.tambahManga(new Manga("Naruto", "Masashi Kishimoto", "Shonen", 1999));
        manager.tambahManga("Berserk", "Kentaro Miura", "Seinen", 1989);

        // Polymorphism (Overriding)
        Genre shonen = new Shonen();
        Genre seinen = new Seinen();

        System.out.println(shonen.deskripsiGenre());
        System.out.println(seinen.deskripsiGenre());

        System.out.println("\nDaftar Manga:");
        manager.tampilkanManga();
    }
}