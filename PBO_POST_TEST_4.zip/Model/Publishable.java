public interface Publishable {
    String publishInfo();
}