public abstract class Genre {
    protected String nama;

    public Genre(String nama) {
        this.nama = nama;
    }

    public abstract String deskripsiGenre();
}