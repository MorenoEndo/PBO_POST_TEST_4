public class Shonen extends Genre {
    public Shonen() {
        super("Shonen");
    }

    @Override
    public String deskripsiGenre() {
        return "Shonen: Manga yang ditujukan untuk pembaca muda laki-laki, penuh aksi dan petualangan.";
    }
}