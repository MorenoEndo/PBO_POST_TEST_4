public class Seinen extends Genre {
    public Seinen() {
        super("Seinen");
    }

    @Override
    public String deskripsiGenre() {
        return "Seinen: Manga dengan cerita lebih serius, biasanya untuk pembaca dewasa.";
    }
}