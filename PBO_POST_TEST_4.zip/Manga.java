public class Manga implements Publishable {
    private String judul;
    private String author;
    private String genre;
    private int tahun;

    public Manga(String judul, String author, String genre, int tahun) {
        this.judul = judul;
        this.author = author;
        this.genre = genre;
        this.tahun = tahun;
    }

    public String getJudul() { return judul; }
    public String getAuthor() { return author; }
    public String getGenre() { return genre; }
    public int getTahun() { return tahun; }

    @Override
    public String publishInfo() {
        return "Manga: " + judul + " | Author: " + author + " | Genre: " + genre + " | Tahun: " + tahun;
    }
}