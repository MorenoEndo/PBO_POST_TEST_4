import java.util.ArrayList;

public class MangaManager {
    private ArrayList<Manga> daftarManga = new ArrayList<>();

    // Overloading
    public void tambahManga(Manga manga) {
        daftarManga.add(manga);
    }

    public void tambahManga(String judul, String author, String genre, int tahun) {
        Manga manga = new Manga(judul, author, genre, tahun);
        daftarManga.add(manga);
    }

    public void tampilkanManga() {
        for (Manga m : daftarManga) {
            System.out.println(m.publishInfo());
        }
    }
}